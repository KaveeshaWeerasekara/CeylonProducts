import React from "react";
import Updates1 from "../../components/seller Panel/Earnings/Updates/Updates1";
import Echart from "./Echart";




function SEarnings() {
    return (
      <div >
        <div className=" pl-12 text-5xl text-[#e47740] 	">Welcome , NAME</div>
        <Updates1/>
        <div className=" container">
          <Echart /> 
        
        </div>
        
      </div>
    );
  }
  
  export default SEarnings;