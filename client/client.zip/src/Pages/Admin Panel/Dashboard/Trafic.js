import React from "react";

//Exopt Network Trafi Details
export default function Trafic() {
  return (
    <div>
      <h1>Network Trafic details...</h1>
    </div>
  );
}
