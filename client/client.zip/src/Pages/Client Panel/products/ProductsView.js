import React from "react";
import ProductView from "../../../components/Client Panel/Product/ProductView";


const ProductsView = () => {
 return(
   <>
   <h1>ProductsView</h1>
   <ProductView />
   </>
  );
};
export default ProductsView;