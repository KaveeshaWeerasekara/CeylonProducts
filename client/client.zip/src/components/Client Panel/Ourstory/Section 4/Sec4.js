import ImgText from "./ImgText";


export default function Sec4() {
  return (
    <div>
      <ImgText />
      <br></br>
      <div className=" container">
      </div>
      <br></br>
    </div>
  );
}
