import React from 'react';

export default function ContactCeylon() {
  return (
    <div>
         <iframe width="650px" height="715px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2019415.4707997658!2d79.40926569599728!3d8.675298024905514!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae2593cf65a1e9d%3A0xe13da4b400e2d38c!2sSri%20Lanka!5e0!3m2!1sen!2slk!4v1647448547108!5m2!1sen!2slk"    loading="lazy"></iframe> 
      
    </div>
  )
}
