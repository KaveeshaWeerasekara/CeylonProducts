import ImgText from "./ImgText";
import Member from "./Member";

export default function Sec4() {
  return (
    <div>
      <ImgText />
      <br></br>
      <div className=" container">
        <Member />
      </div>
      <br></br>
    </div>
  );
}
