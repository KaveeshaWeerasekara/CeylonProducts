import React from 'react'

import Header from '../../loginAndSignup/imports/Header';

export default function Home() {
  return (
   <>
  <Header></Header>
    <main>
      <div className='container'>
        <h4>Welcome to Ceylon Products</h4>
    </div>
    </main>
  </>
  )
}
